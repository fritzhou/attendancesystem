// /js/config.js
// Public, client-safe values only. The anon/publishable key is
// designed to be exposed in frontend code — it has no power beyond
// what your RLS policies allow.

export const SUPABASE_URL = 'https://tldurxdnswzzrkvfyzlr.supabase.co';
export const SUPABASE_PUBLISHABLE_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRsZHVyeGRuc3d6enJrdmZ5emxyIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODk1OTM4MzAsImV4cCI6MjEwNTE2OTgzMH0.VvCGPR3tRyamLtKmo0_kDNxLAYM3pmgU8EZKCCsP3qI';

export const SCHOOL_NAME = 'Pilgrim Christian College';